#include <iostream>
#include <curl/curl.h>
using namespace std;
int argInstall(string pkg) {
	return 0;
}
int argInstallNoName() {
	return 0;
}

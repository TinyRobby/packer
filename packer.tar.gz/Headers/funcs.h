#ifndef FUNCS_H
#define FUNCS_H
#include <iostream>
int argInstallNoName() {
	std::cout << "e";
	return 0;
}
int argInstall(std::string pkg) {
	std::cout << "ea";
	return 0;
}
#endif
